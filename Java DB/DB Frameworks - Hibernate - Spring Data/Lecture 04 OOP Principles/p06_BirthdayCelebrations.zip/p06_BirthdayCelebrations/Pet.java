package march13_Softuni.p06_BirthdayCelebrations;

/**
 * Created by fluch on 3/13/2018.
 */
class Pet {
    private String name;
    private String birthDate;

    public Pet() {

    }

    public Pet(String name, String birthDate) {
        this.name = name;
        this.birthDate = birthDate;
    }


}
